#!/bin/bash
./rev $1.satoutput $1.graph $1.subgraphs

