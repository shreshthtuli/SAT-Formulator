#!/bin/bash
g++ -O2 -march=native -o conv main1.cpp
g++ -O2 -march=native -o rev main2.cpp

