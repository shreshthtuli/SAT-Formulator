#!/bin/bash
./conv $1.graph $1.satinput

